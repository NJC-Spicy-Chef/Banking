from abc import ABC, abstractmethod


# abstract class


class Account(ABC):
    # protected class variables
    _starting_balance = 0
    _current_balance = 0
    _total_deposits = 0
    _number_deposits = 0
    _total_withdrawals = 0
    _number_withdrawals = 0
    _annual_interest_rate = 0
    _service_charge = 0
    _current_account_status = True

    # local class variable to capture the interest amount to display in the monthly report
    monthly_interest_report = 0

    @abstractmethod
    def __init__(self, balance, interest):
        # If the program is still running (no reporting yet) and the starting balance/interest are non-zero, keep them:
        if self._starting_balance == 0:
            self._starting_balance = self._current_balance = balance
        if self._annual_interest_rate == 0:
            self._annual_interest_rate = interest

    # Method to capture deposits for this and all derived classes
    def makeDeposit(self, amount):
        self._current_balance += amount
        self._number_deposits += 1
        self._total_deposits += amount

    # Method to capture withdrawals for this and all derived classes
    def makeWithdraw(self, amount):
        self._current_balance -= amount
        self._number_withdrawals += 1
        self._total_withdrawals += amount

    # Method to calculate the monthly interest
    def calculateInterest(self):
        monthly_interest_rate = self._annual_interest_rate / 12
        monthly_interest = self._current_balance * monthly_interest_rate
        self._current_balance += monthly_interest
        self.monthly_interest_report = monthly_interest
        # print('Monthly Interest Earned: ' + '${:5,.2f}'.format(monthly_interest))

    # Method to print the monthly report for this and all derived classes
    def doMonthlyReport(self):
        self._current_balance -= self._service_charge

        self.calculateInterest()

        print("Starting Balance: " + '${:5,.2f}'.format(self._starting_balance))
        print("Total Amount of Deposits: " + '${:5,.2f}'.format(self._total_deposits))
        print("Total Amount of Withdrawals: " + '${:5,.2f}'.format(self._total_withdrawals))
        print("Service Charges: " + '${:5,.2f}'.format(self._service_charge))
        print("Monthly interest earned: " + '${:5,.2f}'.format(self.monthly_interest_report - self._service_charge))
        print("Current Balance: " + '${:5,.2f}'.format(self._current_balance))
        if self._current_account_status:
            print("Account Status: Active")
        else:
            print("Account Status: Inactive")

        self._starting_balance = self._current_balance
        self._total_deposits = 0
        self._number_deposits = 0
        self._total_withdrawals = 0
        self._number_withdrawals = 0
        self._service_charge = 0
