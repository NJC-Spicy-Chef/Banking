from Account import *


class Checking(Account):
    def __init__(self, balance, interest):
        super().__init__(balance, interest)

    def test_account_balance(self):
        if self._current_balance < 25:
            Account._current_account_status = False

    # This will call the withdrawal method of the Account super class per stated conditions:

    def makeWithdraw(self, amount):
        if self._current_balance - amount < 0:
            self._service_charge += 15
            print("Insufficient funds for withdrawal.")
        else:
            super().makeWithdraw(amount)
            print(f"Withdrawals amount of: ", '${:5,.2f}'.format(amount),
                  "from a current account of ",
                  '${:5,.2f}'.format(self._starting_balance), "\nCurrent balance is ",
                  '${:5,.2f}'.format(self._starting_balance - self._total_withdrawals),
                  "\n\nWhat would you like to do next?\n")

    def makeDeposit(self, amount):
        super().makeDeposit(amount)
        print(f"Added amount: ", '${:5,.2f}'.format(self._total_deposits), "to a starting account of ",
              '${:5,.2f}'.format(self._starting_balance), "\nCurrent balance is ",
              '${:5,.2f}'.format(self._total_deposits + self._starting_balance),
              "\n\nWhat would you like to do next?\n")

    # This will call the monthly report method of the Account super class per stated conditions:

    def doMonthlyReport(self):
        self._service_charge = self._service_charge + 5 + (0.10 * float(self._number_withdrawals))
        super().doMonthlyReport()
