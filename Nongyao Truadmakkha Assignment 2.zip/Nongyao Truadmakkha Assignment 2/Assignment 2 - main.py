from Savings import *
from Checking import *
from datetime import date

today = date.today()


def main():
    print(today, "\nWelcome to '\u03A8 Make Me Rich Bank \u03A8'\nPlease select your account:\n")
    bank_menu_string = "Bank Menu\n\nA: Savings\nB: Checking\nC: Exit\n\n"
    accounts_menu_string = "A: Deposit\nB: Withdrawal\nC: Report\nD: Return to Bank Menu\n\n"

    # Create objects for both the savings and checking accounts:
    s = Savings(100000, 0.1)
    c = Checking(100000, 0.5)

    while True:
        # Display the main Bank menu. This program will exit only when the user selects option 'C':
        bank_menu = input(bank_menu_string)

        # Savings menu. The try/except blocks will allow only floats to be passed to the objects:
        if bank_menu.upper() == "A":
            while True:
                savings_menu = input("Savings Menu\n\n" + accounts_menu_string)
                if savings_menu.upper() == 'A':
                    savings_deposit_input = input("Please input deposit amount: ")
                    try:
                        s.makeDeposit(float(savings_deposit_input))
                    except ValueError:
                        print("Invalid amount entered.\n")
                if savings_menu.upper() == "B":
                    savings_withdrawal_input = input("Please input withdrawal amount: ")
                    try:
                        s.makeWithdraw(float(savings_withdrawal_input))
                    except ValueError:
                        print("Invalid amount entered.\n")
                if savings_menu.upper() == 'C':
                    print("Savings Account Monthly Reports:")
                    s.doMonthlyReport()
                    print("\n")
                if savings_menu.upper() == "D":
                    break
                else:
                    continue

        # Checking menu. The try/except blocks will allow only floats to be passed to the objects:
        if bank_menu.upper() == "B":
            while True:
                checking_menu = input("Checking Menu\n\n" + accounts_menu_string)
                if checking_menu.upper() == "A":
                    checking_deposit_input = input("Please input deposit amount: ")
                    try:
                        c.makeDeposit(float(checking_deposit_input))
                    except ValueError:
                        print("Invalid amount entered.\n")
                if checking_menu.upper() == 'B':
                    checking_withdrawal_input = input("Please input withdrawal amount: ")
                    try:
                        c.makeWithdraw(float(checking_withdrawal_input))
                    except ValueError:
                        print("Invalid amount entered.\n")
                if checking_menu.upper() == "C":
                    print("Checking Account Monthly Reports:")
                    c.doMonthlyReport()
                    print('\n')
                if checking_menu.upper() == "D":
                    break
                else:
                    continue

        # Exit:
        if bank_menu.upper() == "C":
            break
        else:
            continue


if __name__ == "__main__":
    main()
